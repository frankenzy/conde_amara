@extends('layouts.template')

@push('style')
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
@endpush


@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Register') }}</div>

                    <div class="card-body">
                        <form method="POST" action="{{ route('projet.store') }}">
                            @csrf
                            <div class="row mb-3">
                                <label for="nom"
                                    class="col-md-4 col-form-label text-md-end">{{ __('Nom du projet') }}</label>

                                <div class="col-md-6">
                                    <input id="nom" type="text"
                                        class="border ps-2 form-control @error('nom') is-invalid @enderror" name="nom"
                                        value="{{ old('nom') }}" required autocomplete="nom" autofocus>

                                    @error('nom')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="porteur_projets"
                                    class="col-md-4 col-form-label text-md-end">{{ __('Porteur projet') }}</label>

                                <div class="col-md-6">

                                    <select class="form-select border ps-2 form-control @error('porteur_projets') is-invalid @enderror"
                                        name="porteur_projets" required id="porteur_projets">
                                        <option selected>Porteur de projet</option>
                                        @foreach ($porteur_projets as $p)
                                            <option value="{{ $p->id }}" id="porteur_projets-{{ $p->id }}">
                                                {{ $p->nom }}</option>
                                        @endforeach
                                    </select>

                                    @error('porteur_projets')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="type_projets"
                                    class="col-md-4 col-form-label text-md-end">{{ __('Type projet') }}</label>

                                <div class="col-md-6">

                                    <select class="form-select border ps-2 form-control @error('type_projets') is-invalid @enderror"
                                        name="type_projets" required id="type_projets">
                                        <option selected>Type de projet</option>
                                        @foreach ($type_projets as $p)
                                            <option value="{{ $p->id }}" id="type_projets-{{ $p->id }}">
                                                {{ $p->libelle }}</option>
                                        @endforeach
                                    </select>

                                    @error('type_projets')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>


                            <div class="row mb-3">
                                <label for="var"
                                    class="col-md-4 col-form-label text-md-end">{{ __('Valeur actuellement Nette') }}</label>

                                <div class="col-md-6">
                                    <input id="var" type="number"
                                        class="border ps-2 form-control @error('var') is-invalid @enderror" name="var"
                                        value="{{ old('var') }}" required autocomplete="var">

                                    @error('var')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="tri"
                                    class="col-md-4 col-form-label text-md-end">{{ __('Taux de Rentabilité  Interne') }}</label>

                                <div class="col-md-6">
                                    <input id="tri" type="number"
                                        class="border ps-2 form-control @error('tri') is-invalid @enderror" name="tri"
                                        required autocomplete="TRI" value="">
                                    <div class="range">
                                        <div class="d-flex justify-content-around">
                                            <span>0</span>
                                            <div class="col"></div>
                                            <span>5 000 000</span>
                                        </div>
                                        <input type="range" class="form-range" step="5" min="0"
                                            max="5 000 000" id="customRange" />
                                    </div>

                                    @error('tri')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>




                            <div class="row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        {{ __('SOUMETTRE') }}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@push('script')
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <script>
        const range = new mdb.Range(document.getElementById('range'));
        import {
            Range
        } from 'mdb-ui-kit';

        $('#customRange').on('change', function() {
            console.log("hello")
        })

        function updateTextInput(val) {
            $('#pTri').value = val;
        }
    </script>
@endpush
